# __init__.py

# Import the calculator module
from . import calculator as calculate