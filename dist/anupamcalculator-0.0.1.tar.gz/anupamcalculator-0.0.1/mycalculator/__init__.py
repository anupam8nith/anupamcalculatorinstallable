# __init__.py

# Import the calculator module
from anupamcalculator.mycalculator import calculator